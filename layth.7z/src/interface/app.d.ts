export interface optionListArrayInterface {
  title: string
  img: string
  url?: string
}
