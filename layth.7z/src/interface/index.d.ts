export type { loginParamsInterface } from './user'
export type { optionListArrayInterface } from './app'
