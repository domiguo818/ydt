export interface loginParamsInterface {
  authCode: string
}
