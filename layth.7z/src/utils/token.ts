export const TOKEN_NAME = 'linan_token'
