import { createApp } from 'vue'
import ArcoVue from '@arco-design/web-vue';
import App from './App.vue'
import '@arco-design/web-vue/dist/arco.css';
import router from './router'
import FightingDesign from 'fighting-design'
import 'fighting-design/dist/index.css'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
const app = createApp(App)

for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
    app.component(key, component)
  }

createApp(App).use(router).use(FightingDesign,ArcoVue,).use(ElementPlus).mount('#app')
